browser.runtime.onInstalled.addListener((details) => {
  if (details.reason === "install") {
    const defaultSites = [
      { 
        name: "Online Fix",
        enabled: true,
        url: "https://online-fix.me/",
        iconUrl: "https://i.imgur.com/WAXRAUw.png",
        isDefault: true
      },
      { 
        name: "Skidrow",
        enabled: true,
        url: "https://www.skidrowreloaded.com/",
        iconUrl: "https://i.imgur.com/qRtlnsn.png",
        isDefault: true
      },
      { 
        name: "FitGirl",
        enabled: true,
        url: "https://fitgirl-repacks.site/",
        iconUrl: "https://i.imgur.com/GOFbweI.png",
        isDefault: true
      },
      { 
        name: "SteamRIP",
        enabled: true,
        url: "https://steamrip.com/",
        iconUrl: "https://i.imgur.com/tmvOT86.png",
        isDefault: true
      },
      { 
        name: "Dodi",
        enabled: true,
        url: "https://dodi-repacks.site/",
        iconUrl: "https://i.imgur.com/g71t1Ge.png",
        isDefault: true
      },
      { 
        name: "Gload",
        enabled: true,
        url: "https://gload.to/",
        iconUrl: "https://gload.to/logo.png",
        isDefault: true
      },
      { 
        name: "GOG",
        enabled: true,
        url: "https://www.gog-games.to/",
        iconUrl: "https://i.imgur.com/wXfz72C.png",
        isDefault: true
      },
      { 
        name: "Crack Status",
        enabled: true,
        url: "https://crackstatus.net/",
        iconUrl: "https://i.imgur.com/3szizz7.png",
        isDefault: true
      },
      { 
        name: "RuTracker",
        enabled: true,
        url: "https://rutracker.org/",
        iconUrl: "https://i.imgur.com/wOjpyEc.png",
        isDefault: true
      }
    ];

    browser.storage.local.set({ sites: defaultSites }, () => {
      console.log('Default sites initialized');
    });
  }
});

browser.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.action === "openLink" && message.url) {
    browser.tabs.create({ url: message.url });
  }
});
