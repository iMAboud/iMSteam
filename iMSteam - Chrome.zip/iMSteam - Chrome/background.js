chrome.runtime.onMessage.addListener(function(message, sender, sendResponse) {
  if (message.openLink) {
    chrome.storage.local.get(["searchLink"], function(result) {
      const searchLink = result.searchLink;
      if (searchLink) {
        chrome.tabs.create({ "url": searchLink });
      }
    });
  }
});
