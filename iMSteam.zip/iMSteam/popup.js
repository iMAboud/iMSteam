let currentSites = [];
let editingSiteIndex = -1;

function getDefaultSites() {
  return [
    { 
      name: "Online Fix",
      enabled: true,
      url: "https://online-fix.me/",
      iconUrl: "https://i.imgur.com/WAXRAUw.png",
      isDefault: true
    },
    { 
      name: "Skidrow",
      enabled: true,
      url: "https://www.skidrowreloaded.com/",
      iconUrl: "https://i.imgur.com/qRtlnsn.png",
      isDefault: true
    },
    { 
      name: "FitGirl",
      enabled: true,
      url: "https://fitgirl-repacks.site/",
      iconUrl: "https://i.imgur.com/GOFbweI.png",
      isDefault: true
    },
    { 
      name: "SteamRIP",
      enabled: true,
      url: "https://steamrip.com/",
      iconUrl: "https://i.imgur.com/tmvOT86.png",
      isDefault: true
    },
    { 
      name: "Dodi",
      enabled: true,
      url: "https://dodi-repacks.site/",
      iconUrl: "https://i.imgur.com/g71t1Ge.png",
      isDefault: true
    },
    { 
      name: "Gload",
      enabled: true,
      url: "https://gload.to/",
      iconUrl: "https://gload.to/logo.png",
      isDefault: true
    },
    { 
      name: "GOG",
      enabled: true,
      url: "https://www.gog-games.to/",
      iconUrl: "https://i.imgur.com/wXfz72C.png",
      isDefault: true
    },
    { 
      name: "Crack Status",
      enabled: true,
      url: "https://crackstatus.net/",
      iconUrl: "https://i.imgur.com/3szizz7.png",
      isDefault: true
    },
    { 
      name: "RuTracker",
      enabled: true,
      url: "https://rutracker.org/",
      iconUrl: "https://i.imgur.com/wOjpyEc.png",
      isDefault: true
    }
  ];
}

function retrieveSettings() {
  chrome.storage.local.get({ sites: getDefaultSites() }, function(data) {
    currentSites = data.sites;
    renderSiteList(currentSites);
  });
}

function saveSettings(sites) {
  chrome.storage.local.set({ sites: sites }, function() {
    console.log('Settings saved');
  });
}

function renderSiteList(sites) {
  const siteListContainer = document.getElementById("siteList");
  siteListContainer.innerHTML = "";

  sites.forEach((site, index) => {
    const siteDiv = document.createElement("div");
    siteDiv.classList.add("site-item");
    if (!site.enabled) {
      siteDiv.classList.add("disabled-site");
    }

    const siteIcon = document.createElement("img");
    siteIcon.classList.add("site-icon");
    siteIcon.src = site.iconUrl;
    siteIcon.alt = site.name;
    siteDiv.appendChild(siteIcon);

    const siteName = document.createElement("span");
    siteName.classList.add("site-name");
    siteName.textContent = site.name;
    siteDiv.appendChild(siteName);

    const actionsDiv = document.createElement("div");
    actionsDiv.classList.add("site-actions");

    // Edit button
    const editButton = document.createElement("button");
    editButton.classList.add("btn", "btn-icon");
    editButton.innerHTML = "✏️";
    editButton.title = "Edit";
    editButton.onclick = (e) => {
      e.stopPropagation();
      openEditModal(index);
    };
    actionsDiv.appendChild(editButton);

    // Delete button
    const deleteButton = document.createElement("button");
    deleteButton.classList.add("btn", "btn-icon");
    deleteButton.innerHTML = "🗑️";
    deleteButton.title = "Delete";
    deleteButton.onclick = (e) => {
      e.stopPropagation();
      deleteSite(index);
    };
    actionsDiv.appendChild(deleteButton);

    siteDiv.appendChild(actionsDiv);

    siteDiv.addEventListener("click", () => {
      site.enabled = !site.enabled;
      saveSettings(sites);
      renderSiteList(sites);
    });

    siteListContainer.appendChild(siteDiv);
  });
}

function openAddModal() {
  document.getElementById("addSiteModal").style.display = "block";
  document.getElementById("addSiteForm").reset();
  handleIconTypeChange();
}

function closeAddModal() {
  document.getElementById("addSiteModal").style.display = "none";
}

function openEditModal(index) {
  editingSiteIndex = index;
  const site = currentSites[index];
  
  document.getElementById("editSiteName").value = site.name;
  document.getElementById("editSiteUrl").value = site.url;
  document.getElementById("editIconUrl").value = site.iconUrl;
  
  document.getElementById("editIconType").value = "url";
  handleEditIconTypeChange();
  
  document.getElementById("editModal").style.display = "block";
}

function closeEditModal() {
  document.getElementById("editModal").style.display = "none";
  editingSiteIndex = -1;
}

function deleteSite(index) {
  if (confirm("Are you sure you want to delete this site?")) {
    currentSites.splice(index, 1);
    saveSettings(currentSites);
    renderSiteList(currentSites);
  }
}

function handleIconTypeChange() {
  const iconType = document.getElementById("iconType").value;
  document.getElementById("iconUrlGroup").style.display = iconType === "url" ? "block" : "none";
  document.getElementById("iconUploadGroup").style.display = iconType === "upload" ? "block" : "none";
}

function handleEditIconTypeChange() {
  const iconType = document.getElementById("editIconType").value;
  document.getElementById("editIconUrlGroup").style.display = iconType === "url" ? "block" : "none";
  document.getElementById("editIconUploadGroup").style.display = iconType === "upload" ? "block" : "none";
}

function resetToDefault() {
  if (confirm("This will restore all default sites. Custom sites will remain unchanged. Continue?")) {
    const customSites = currentSites.filter(site => !site.isDefault);
    const defaultSites = getDefaultSites();
    currentSites = [...defaultSites, ...customSites];
    saveSettings(currentSites);
    renderSiteList(currentSites);
  }
}

// Event Listeners
document.addEventListener("DOMContentLoaded", () => {
  retrieveSettings();
  
  document.getElementById("addSiteBtn").addEventListener("click", openAddModal);
  document.getElementById("closeAddModal").addEventListener("click", closeAddModal);
  document.getElementById("cancelAdd").addEventListener("click", closeAddModal);
  
  document.getElementById("addSiteForm").addEventListener("submit", async (e) => {
    e.preventDefault();
    
    const name = document.getElementById("siteName").value;
    let url = document.getElementById("siteUrl").value.trim();
    const iconType = document.getElementById("iconType").value;
    let iconUrl;
    
    if (iconType === "url") {
      iconUrl = document.getElementById("iconUrl").value;
    } else {
      const iconFile = document.getElementById("iconFile").files[0];
      if (iconFile) {
        const reader = new FileReader();
        iconUrl = await new Promise((resolve) => {
          reader.onload = (e) => resolve(e.target.result);
          reader.readAsDataURL(iconFile);
        });
      }
    }
    
    const newSite = {
      name,
      url,
      iconUrl,
      enabled: true,
      isDefault: false
    };
    
    currentSites.push(newSite);
    saveSettings(currentSites);
    renderSiteList(currentSites);
    closeAddModal();
  });
  
  document.getElementById("editSiteForm").addEventListener("submit", async (e) => {
    e.preventDefault();
    
    if (editingSiteIndex === -1) return;
    
    const site = currentSites[editingSiteIndex];
    site.name = document.getElementById("editSiteName").value;
    site.url = document.getElementById("editSiteUrl").value.trim();
    
    const iconType = document.getElementById("editIconType").value;
    if (iconType === "url") {
      site.iconUrl = document.getElementById("editIconUrl").value;
    } else {
      const iconFile = document.getElementById("editIconFile").files[0];
      if (iconFile) {
        const reader = new FileReader();
        site.iconUrl = await new Promise((resolve) => {
          reader.onload = (e) => resolve(e.target.result);
          reader.readAsDataURL(iconFile);
        });
      }
    }
    
    saveSettings(currentSites);
    renderSiteList(currentSites);
    closeEditModal();
  });
  
  document.getElementById("closeEditModal").addEventListener("click", closeEditModal);
  document.getElementById("cancelEdit").addEventListener("click", closeEditModal);
  document.getElementById("iconType").addEventListener("change", handleIconTypeChange);
  document.getElementById("editIconType").addEventListener("change", handleEditIconTypeChange);
  document.getElementById("resetDefault").addEventListener("click", resetToDefault);
});
